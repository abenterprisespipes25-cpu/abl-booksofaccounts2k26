import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { MODULES, ModuleId } from "@/lib/abl/config";
import { sortMonthYears, monthYearToTabLabel } from "@/lib/abl/format";
import { parseCDB, parsePurchaseBook, parseSalesBook, parseCashReceipts, ParsedResult } from "@/lib/abl/parsers";
import { exportExcel, exportPDF } from "@/lib/abl/exporters";
import { MonthTabs } from "./MonthTabs";
import { LedgerTable } from "./LedgerTable";
import { Button } from "@/components/ui/button";
import { Upload, FileSpreadsheet, FileText, Save, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const PARSERS: Record<ModuleId, (buf: ArrayBuffer) => ParsedResult<any>> = {
  cdb: parseCDB,
  purchase_book: parsePurchaseBook,
  sales_book: parseSalesBook,
  cash_receipts: parseCashReceipts,
};

export default function BookModule({ moduleId }: { moduleId: ModuleId }) {
  const meta = MODULES[moduleId];
  const [months, setMonths] = useState<string[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [pending, setPending] = useState<{ parsed: ParsedResult<any>; fileName: string } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  async function loadMonths() {
    const { data } = await supabase.from(meta.tableName).select("month_year");
    const list = sortMonthYears((data ?? []).map((r: any) => r.month_year));
    setMonths(list);
    if (list.length && (!active || !list.includes(active))) setActive(list[list.length - 1]);
    if (!list.length) { setActive(null); setRows([]); }
  }

  async function loadRows(my: string) {
    setLoading(true);
    const { data } = await supabase
      .from(meta.tableName)
      .select("*")
      .eq("month_year", my)
      .order("entry_date", { ascending: true });
    const list = data ?? [];
    const subKey = moduleId === "cdb" || moduleId === "purchase_book" ? "sundries_acct_title" : null;
    const sortKey = moduleId === "cdb" ? "check_voucher_no" : moduleId === "purchase_book" ? "invoice_no" : null;
    const parentMarker = moduleId === "cdb" ? "check_no" : moduleId === "purchase_book" ? "invoice_no" : null;
    if (sortKey && subKey && parentMarker) {
      // Group parent + sundry sub-rows
      const groups: any[][] = [];
      let cur: any[] = [];
      for (const r of list) {
        const isSub = !String(r[parentMarker] ?? "").trim() && String(r[subKey] ?? "").trim() !== "";
        if (!isSub) { if (cur.length) groups.push(cur); cur = [r]; } else { cur.push(r); }
      }
      if (cur.length) groups.push(cur);
      const natural = (a: string, b: string) => {
        const seg = (s: string) => String(s ?? "").replace(/[^\w]/g, " ").trim().split(/(\d+)/).filter(Boolean).map(x => /^\d+$/.test(x) ? parseInt(x, 10) : x.toLowerCase());
        const sa = seg(a), sb = seg(b), L = Math.max(sa.length, sb.length);
        for (let i = 0; i < L; i++) { const x = sa[i] ?? "", y = sb[i] ?? ""; if (x === y) continue; if (typeof x === "number" && typeof y === "number") return x - y; if (typeof x === "number") return -1; if (typeof y === "number") return 1; return x < y ? -1 : 1; }
        return 0;
      };
      groups.sort((g1, g2) => {
        const a = g1[0], b = g2[0];
        const d = String(a.entry_date ?? "").localeCompare(String(b.entry_date ?? ""));
        if (d !== 0) return d;
        const sk = natural(String(a[sortKey] ?? ""), String(b[sortKey] ?? ""));
        if (sk !== 0) return sk;
        return String(a.payee ?? a.supplier ?? "").localeCompare(String(b.payee ?? b.supplier ?? ""));
      });
      setRows(groups.flat());
    } else {
      setRows(list);
    }
    setLoading(false);
  }

  useEffect(() => { loadMonths(); /* eslint-disable-next-line */ }, [moduleId]);
  useEffect(() => { if (active) loadRows(active); }, [active]);

  async function handleFile(file: File) {
    setUploading(true);
    try {
      const buf = await file.arrayBuffer();
      const parsed = PARSERS[moduleId](buf);
      const monthsInFile = Array.from(new Set(parsed.rows.map((r: any) => r.month_year))).filter(Boolean) as string[];
      toast.message(`Parsing ${parsed.rows.length} rows across ${monthsInFile.length} month(s) from ${file.name}...`);
      const { data: existing } = await supabase
        .from(meta.tableName)
        .select("month_year")
        .in("month_year", monthsInFile);
      const existingMonths = Array.from(new Set((existing ?? []).map((r: any) => r.month_year)));
      if (existingMonths.length > 0) {
        setPending({ parsed, fileName: file.name });
      } else {
        await commit(parsed, file.name);
      }
    } catch (e: any) {
      toast.error(`Upload error: ${e.message || e}`);
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function commit(parsed: ParsedResult<any>, fileName: string, replace = false) {
    try {
      setUploading(true);
      const monthsInFile = Array.from(new Set(parsed.rows.map((r: any) => r.month_year))).filter(Boolean) as string[];
      const glMonthsInFile = Array.from(new Set(parsed.glEntries.map((r: any) => r.month_year))).filter(Boolean) as string[];
      if (replace) {
        for (const my of monthsInFile) {
          await supabase.from(meta.tableName).delete().eq("month_year", my);
          await supabase.from("uploaded_files").delete()
            .eq("module", meta.glSource)
            .eq("month_year", my);
        }
        for (const my of glMonthsInFile) {
          await supabase.from("gl_entries").delete()
            .eq("source_module", meta.glSource)
            .eq("month_year", my);
        }
      }
      // Batch insert
      const BATCH = 50;
      for (let i = 0; i < parsed.rows.length; i += BATCH) {
        const chunk = parsed.rows.slice(i, i + BATCH);
        const { error } = await supabase.from(meta.tableName).insert(chunk as any);
        if (error) throw error;
      }
      if (parsed.glEntries.length) {
        for (let i = 0; i < parsed.glEntries.length; i += BATCH) {
          const chunk = parsed.glEntries.slice(i, i + BATCH);
          const { error } = await supabase.from("gl_entries").insert(chunk as any);
          if (error) throw error;
        }
      }
      for (const my of monthsInFile) {
        const rowCount = parsed.rows.filter((r: any) => r.month_year === my).length;
        await supabase.from("uploaded_files").insert({
          module: meta.glSource,
          month_year: my,
          file_name: fileName,
          row_count: rowCount,
        } as any);
      }
      toast.success(`✓ Imported ${parsed.rows.length} transactions across ${monthsInFile.length} month(s): ${monthsInFile.join(", ")}`);
      setActive(monthsInFile[monthsInFile.length - 1] ?? parsed.monthYear);
      await loadMonths();
    } catch (e: any) {
      toast.error(`Save failed: ${e.message || e}`);
    } finally {
      setUploading(false);
      setPending(null);
    }
  }

  const bookName = meta.label.toUpperCase();
  const filenameBase = `ABL_${meta.glSource}_${active ?? "EMPTY"}`.replace(/\s+/g, "_");

  return (
    <div className="space-y-4">
      {/* Action bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-primary">{meta.label}</h2>
          <p className="text-xs text-muted-foreground">{meta.uploadHint}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <input
            ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />
          <Button onClick={() => fileRef.current?.click()} disabled={uploading}>
            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            Upload Excel
          </Button>
          <Button variant="secondary" onClick={() => active && loadRows(active)}>
            <Save className="h-4 w-4" /> Save
          </Button>
          <Button
            variant="outline"
            disabled={!rows.length}
            onClick={() => active && exportExcel({
              filename: `${filenameBase}.xlsx`,
              bookName, monthYear: active, columns: meta.columns, rows,
            })}
          >
            <FileSpreadsheet className="h-4 w-4" /> Export Excel
          </Button>
          <Button
            variant="outline"
            disabled={!rows.length}
            onClick={() => active && exportPDF({
              filename: `${filenameBase}.pdf`,
              bookName, monthYear: active, columns: meta.columns, rows,
            })}
          >
            <FileText className="h-4 w-4" /> Export PDF
          </Button>
        </div>
      </div>

      {/* Month tabs */}
      {months.length > 0 && (
        <MonthTabs months={months} active={active} onSelect={setActive} />
      )}

      {loading ? (
        <div className="flex items-center justify-center py-16 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin mr-2" /> Loading...
        </div>
      ) : (
        <LedgerTable columns={meta.columns} rows={rows} />
      )}

      <AlertDialog open={!!pending} onOpenChange={(o) => !o && setPending(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Data already exists</AlertDialogTitle>
            <AlertDialogDescription>
              Data for <strong>{pending?.parsed.monthYear}</strong> already exists in {meta.label}.
              Replace it? This will also remove the related General Ledger entries for this month.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => pending && commit(pending.parsed, pending.fileName, true)}>
              Replace
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
