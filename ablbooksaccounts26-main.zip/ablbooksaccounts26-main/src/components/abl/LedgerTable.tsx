import { ColumnDef } from "@/lib/abl/config";
import { fmtDate, fmtMoney } from "@/lib/abl/format";

export function LedgerTable({
  columns, rows, showTotals = true, emptyMessage = "No entries. Upload an Excel file to get started.",
}: {
  columns: ColumnDef[]; rows: any[]; showTotals?: boolean; emptyMessage?: string;
}) {
  if (!rows.length) {
    return (
      <div className="border border-dashed border-border rounded-md p-10 text-center text-sm text-muted-foreground">
        {emptyMessage}
      </div>
    );
  }
  const totals: Record<string, number> = {};
  for (const c of columns) {
    if (c.type === "currency") {
      totals[c.field] = rows.reduce((s, r) => s + (Number(r[c.field]) || 0), 0);
    }
  }
  return (
    <div className="overflow-auto border border-border rounded-md bg-card max-w-full">
      <table className="ledger-table">
        <thead>
          <tr>
            {columns.map((c, i) => (
              <th key={i} style={{ minWidth: c.width, width: c.width }} className={c.type === "currency" ? "text-right" : ""}>
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, ri) => (
            <tr key={r.id ?? ri}>
              {columns.map((c, ci) => (
                <td key={ci} className={c.type === "currency" ? "num" : ""}>
                  {c.type === "currency"
                    ? fmtMoney(r[c.field])
                    : c.type === "date"
                    ? fmtDate(r[c.field])
                    : r[c.field] ?? ""}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
        {showTotals && (
          <tfoot>
            <tr>
              {columns.map((c, i) => (
                <td key={i} className={c.type === "currency" ? "num" : ""}>
                  {c.type === "currency" ? fmtMoney(totals[c.field]) : i === 0 ? "TOTAL" : ""}
                </td>
              ))}
            </tr>
          </tfoot>
        )}
      </table>
    </div>
  );
}
