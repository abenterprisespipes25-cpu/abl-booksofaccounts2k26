import { cn } from "@/lib/utils";

export function MonthTabs({
  months, active, onSelect,
}: { months: string[]; active: string | null; onSelect: (m: string) => void }) {
  if (!months.length) return null;
  const abbr = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
  const monthsFull = ["JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER"];
  return (
    <div className="flex flex-wrap gap-1 pb-0">
      {months.map((m) => {
        const [name, year] = m.split(" ");
        const idx = monthsFull.indexOf(name);
        const label = idx >= 0 ? `${abbr[idx]} ${year}` : m;
        return (
          <button
            key={m}
            onClick={() => onSelect(m)}
            className={cn("month-tab", active === m && "active")}
          >
            {label}
          </button>
        );
      })}
    </div>
  );
}
