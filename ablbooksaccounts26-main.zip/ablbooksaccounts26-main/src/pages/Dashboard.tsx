import { useNavigate } from "react-router-dom";
import { ModuleIcon, ModuleKey, MODULE_THEME } from "@/components/ModuleIcons";

type GridModule = {
  key: ModuleKey;
  name: string;
  to: string;
};

const MODULES: GridModule[] = [
  { key: "cdb", name: "Cash Disbursements", to: "/cdb" },
  { key: "receipts", name: "Cash Receipts", to: "/cash-receipts" },
  { key: "sales", name: "Sales Book", to: "/sales-book" },
  { key: "purchase", name: "Purchase Book", to: "/purchase-book" },
  { key: "ledger", name: "General Ledger", to: "/general-ledger" },
  { key: "trial", name: "Trial Balance", to: "/trial-balance" },
];

export default function Dashboard() {
  const navigate = useNavigate();

  return (
    <div
      className="min-h-[calc(100vh-8rem)] w-full flex items-center justify-center"
      style={{ padding: "20px" }}
    >
      <div className="w-full max-w-4xl">
        <div className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-black tracking-tight text-white">
            ABL Books of Accounts
          </h1>
          <p className="text-sm text-white/70 mt-1">By: Adrian Llano</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-5 sm:gap-6">
          {MODULES.map((m) => {
            const color = MODULE_THEME[m.key].color;
            return (
              <button
                key={m.key}
                onClick={() => navigate(m.to)}
                className="neon-glass-card group"
                style={{
                  ["--glow" as any]: color,
                }}
              >
                <div className="neon-glass-icon">
                  <ModuleIcon moduleKey={m.key} size={64} />
                </div>
                <span className="neon-glass-label">{m.name}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
