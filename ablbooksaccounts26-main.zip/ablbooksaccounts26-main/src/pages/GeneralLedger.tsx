import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { sortMonthYears, parseMonthYear, folioFor, round2 } from "@/lib/abl/format";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FileText, Printer, Search, Loader2 } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { getCompanySettings, CompanySettings } from "@/lib/abl/companySettings";

interface GL {
  id: string;
  entry_date: string;
  account_name: string;
  particulars: string;
  folio: string;
  debit: number;
  credit: number;
  source_module: string;
  month_year: string;
}

interface TEntry { date: string; particulars: string; folio: string; amount: number; sortKey: string; }
interface TAccount { accountName: string; debitRows: TEntry[]; creditRows: TEntry[]; }

const MODULE_PARTICULARS: Record<string, string> = {
  CDB: "Disbursements",
  PB: "Purchases",
  SB: "Sales",
  CR: "Collections",
  JB: "General Journal Entries",
};

const MONTH_ABBR = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
const MONTH_SHORT = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

function lastDayLabel(monthYear: string): string {
  const p = parseMonthYear(monthYear);
  if (!p) return monthYear;
  const last = new Date(p.year, p.month + 1, 0).getDate();
  return `${MONTH_SHORT[p.month]} ${last}`;
}

function fmt(n: number) {
  return n > 0 ? n.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "";
}

export default function GeneralLedger() {
  const [rows, setRows] = useState<GL[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [settings, setSettings] = useState<CompanySettings | null>(null);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const [glRes, s] = await Promise.all([
        supabase.from("gl_entries").select("*").order("entry_date", { ascending: true }),
        getCompanySettings(),
      ]);
      setRows((glRes.data ?? []) as any);
      setSettings(s);
      setLoading(false);
    })();
  }, []);

  // Always include ALL months — no month filter on GL
  const periodRows = rows;

  // Build T-Accounts: account → month → module → {dr, cr}
  const tAccounts = useMemo<TAccount[]>(() => {
    const map = new Map<string, Map<string, Map<string, { dr: number; cr: number }>>>();
    for (const r of periodRows) {
      const acct = r.account_name;
      const mod = (r.source_module || "JB").toUpperCase();
      if (!map.has(acct)) map.set(acct, new Map());
      const byMonth = map.get(acct)!;
      if (!byMonth.has(r.month_year)) byMonth.set(r.month_year, new Map());
      const byMod = byMonth.get(r.month_year)!;
      if (!byMod.has(mod)) byMod.set(mod, { dr: 0, cr: 0 });
      const cell = byMod.get(mod)!;
      cell.dr = round2(cell.dr + Number(r.debit || 0));
      cell.cr = round2(cell.cr + Number(r.credit || 0));
    }

    const result: TAccount[] = [];
    for (const [accountName, byMonth] of map) {
      const debitRows: TEntry[] = [];
      const creditRows: TEntry[] = [];
      const sortedMonths = sortMonthYears([...byMonth.keys()]);
      for (const my of sortedMonths) {
        const byMod = byMonth.get(my)!;
        const p = parseMonthYear(my);
        const sortKey = p ? `${p.year}-${String(p.month).padStart(2,"0")}` : my;
        for (const [mod, v] of byMod) {
          const date = lastDayLabel(my);
          const particulars = MODULE_PARTICULARS[mod] ?? mod;
          const folio = folioFor(mod, my);
          if (v.dr > 0) debitRows.push({ date, particulars, folio, amount: v.dr, sortKey: sortKey + mod });
          if (v.cr > 0) creditRows.push({ date, particulars, folio, amount: v.cr, sortKey: sortKey + mod });
        }
      }
      debitRows.sort((a,b) => a.sortKey.localeCompare(b.sortKey));
      creditRows.sort((a,b) => a.sortKey.localeCompare(b.sortKey));
      result.push({ accountName, debitRows, creditRows });
    }
    return result.sort((a,b) => a.accountName.localeCompare(b.accountName));
  }, [periodRows]);

  const filteredAccounts = useMemo(
    () => tAccounts.filter((a) => a.accountName.toLowerCase().includes(search.toLowerCase())),
    [tAccounts, search]
  );

  const periodLabel = "All Months";

  function exportPDF() {
    if (!settings) return;
    const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });

    filteredAccounts.forEach((account, idx) => {
      if (idx > 0) doc.addPage();

      doc.setFontSize(11); doc.setFont("helvetica", "bold");
      doc.text(settings.company_name, 148, 12, { align: "center" });
      doc.setFontSize(8); doc.setFont("helvetica", "normal");
      let y = 17;
      if (settings.address) { doc.text(settings.address, 148, y, { align: "center" }); y += 4; }
      if (settings.tin_no) { doc.text(`TIN: ${settings.tin_no}`, 148, y, { align: "center" }); y += 4; }
      doc.setFontSize(10); doc.setFont("helvetica", "bold");
      doc.text("GENERAL LEDGER", 148, y + 2, { align: "center" });
      doc.setFontSize(9); doc.setFont("helvetica", "normal");
      doc.text(`For the Period of ${periodLabel}`, 148, y + 7, { align: "center" });
      doc.setFont("helvetica", "bold");
      doc.text(account.accountName.toUpperCase(), 148, y + 12, { align: "center" });

      const totalDR = round2(account.debitRows.reduce((s, r) => s + r.amount, 0));
      const totalCR = round2(account.creditRows.reduce((s, r) => s + r.amount, 0));
      const balanceDR = totalCR > totalDR ? round2(totalCR - totalDR) : 0;
      const balanceCR = totalDR > totalCR ? round2(totalDR - totalCR) : 0;
      const grandTotal = Math.max(totalDR + balanceDR, totalCR + balanceCR);

      const maxLen = Math.max(account.debitRows.length, account.creditRows.length);
      const body: any[][] = [];
      for (let i = 0; i < maxLen; i++) {
        const dr = account.debitRows[i]; const cr = account.creditRows[i];
        body.push([
          dr?.date ?? "", dr?.particulars ?? "", dr?.folio ?? "", dr ? fmt(dr.amount) : "",
          "",
          cr?.date ?? "", cr?.particulars ?? "", cr?.folio ?? "", cr ? fmt(cr.amount) : "",
        ]);
      }
      if (balanceDR > 0 || balanceCR > 0) {
        body.push(["", "Balance c/d", "", balanceDR > 0 ? fmt(balanceDR) : "", "", "", "Balance c/d", "", balanceCR > 0 ? fmt(balanceCR) : ""]);
      }
      body.push(["", "TOTAL", "", fmt(grandTotal), "", "", "TOTAL", "", fmt(grandTotal)]);

      autoTable(doc, {
        startY: y + 16,
        head: [["DATE","PARTICULARS","FOLIO","DEBIT","","DATE","PARTICULARS","FOLIO","CREDIT"]],
        body,
        styles: { fontSize: 7, cellPadding: 1.5 },
        headStyles: { fillColor: [15, 39, 68], textColor: 255, fontStyle: "bold", halign: "center" },
        columnStyles: {
          3: { halign: "right" },
          4: { cellWidth: 2, fillColor: [15, 39, 68] },
          8: { halign: "right" },
        },
        didParseCell(d) {
          if (d.row.index === body.length - 1) {
            d.cell.styles.fontStyle = "bold";
            if (d.column.index !== 4) d.cell.styles.fillColor = [219, 234, 254];
          } else if ((balanceDR > 0 || balanceCR > 0) && d.row.index === body.length - 2) {
            if (d.column.index !== 4) d.cell.styles.fillColor = [254, 243, 199];
          }
        },
      });
    });
    doc.save(`GL_${settings.company_name.replace(/[^A-Z0-9]+/gi,"_")}_${new Date().toISOString().slice(0,10)}.pdf`);
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3 items-end justify-between no-print">
        <div>
          <h2 className="text-lg font-bold text-white">General Ledger — T-Account</h2>
          <p className="text-xs text-white/60">
            Per-account T-Accounts. Auto-summarized monthly from CDB, PB, SB, CR.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => window.print()}>
            <Printer className="h-4 w-4" /> Print
          </Button>
          <Button variant="outline" disabled={!filteredAccounts.length} onClick={exportPDF}>
            <FileText className="h-4 w-4" /> Export PDF
          </Button>
        </div>
      </div>

      <Card className="p-4 no-print">
        <div>
          <label className="text-xs font-semibold text-muted-foreground">Search Account</label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Filter accounts..."
              className="pl-9"
            />
          </div>
        </div>
      </Card>

      {/* Print header (only visible on print) */}
      <div className="hidden print:block text-center mb-4">
        {settings && (
          <>
            <div className="font-bold text-base">{settings.company_name}</div>
            {settings.address && <div className="text-xs">{settings.address}</div>}
            {settings.tin_no && <div className="text-xs">TIN: {settings.tin_no}</div>}
            <div className="font-bold mt-1">GENERAL LEDGER</div>
            <div className="text-xs">For the Period of {periodLabel}</div>
          </>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-10 text-white/60">
          <Loader2 className="h-5 w-5 animate-spin mr-2" /> Loading ledger...
        </div>
      ) : filteredAccounts.length === 0 ? (
        <Card className="p-10 text-center text-muted-foreground text-sm">
          No GL entries found. Upload data in any book module.
        </Card>
      ) : (
        <div>
          {filteredAccounts.map((acct) => (
            <TAccountCard key={acct.accountName} data={acct} settings={settings} />
          ))}
        </div>
      )}
    </div>
  );
}

function TAccountCard({ data, settings }: { data: TAccount; settings: CompanySettings | null }) {
  const totalDR = round2(data.debitRows.reduce((s, r) => s + r.amount, 0));
  const totalCR = round2(data.creditRows.reduce((s, r) => s + r.amount, 0));
  const balanceDR = totalCR > totalDR ? round2(totalCR - totalDR) : 0;
  const balanceCR = totalDR > totalCR ? round2(totalDR - totalCR) : 0;
  const grandTotal = Math.max(totalDR + balanceDR, totalCR + balanceCR);
  const maxLen = Math.max(data.debitRows.length, data.creditRows.length);

  function exportExcel() {
    const wb = XLSX.utils.book_new();
    const aoa: any[][] = [];
    if (settings) {
      aoa.push([settings.company_name]);
      if (settings.address) aoa.push([settings.address]);
      if (settings.tin_no) aoa.push([`TIN: ${settings.tin_no}`]);
    }
    aoa.push(["GENERAL LEDGER"]);
    aoa.push([data.accountName.toUpperCase()]);
    aoa.push([]);
    aoa.push(["DATE","PARTICULARS","FOLIO","DEBIT","","DATE","PARTICULARS","FOLIO","CREDIT"]);
    for (let i = 0; i < maxLen; i++) {
      const dr = data.debitRows[i]; const cr = data.creditRows[i];
      aoa.push([
        dr?.date ?? "", dr?.particulars ?? "", dr?.folio ?? "", dr ? dr.amount : "",
        "",
        cr?.date ?? "", cr?.particulars ?? "", cr?.folio ?? "", cr ? cr.amount : "",
      ]);
    }
    if (balanceDR > 0 || balanceCR > 0) {
      aoa.push(["", "Balance c/d", "", balanceDR || "", "", "", "Balance c/d", "", balanceCR || ""]);
    }
    aoa.push(["", "TOTAL", "", grandTotal, "", "", "TOTAL", "", grandTotal]);
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [{wch:12},{wch:28},{wch:14},{wch:16},{wch:2},{wch:12},{wch:28},{wch:14},{wch:16}];
    const sheetName = data.accountName.substring(0,31).replace(/[\\/?*[\]]/g,"");
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    XLSX.writeFile(wb, `GL_${data.accountName.replace(/[^a-z0-9]/gi,"_").substring(0,30)}.xlsx`);
  }

  function printAccount() {
    const fmtN = (n: number) => n > 0 ? n.toLocaleString("en-PH",{minimumFractionDigits:2,maximumFractionDigits:2}) : "";
    let rows = "";
    for (let i = 0; i < maxLen; i++) {
      const dr = data.debitRows[i]; const cr = data.creditRows[i];
      rows += `<tr>
        <td>${dr?.date??""}</td><td>${dr?.particulars??""}</td><td>${dr?.folio??""}</td>
        <td style="text-align:right">${dr?fmtN(dr.amount):""}</td>
        <td style="background:#0f2744;width:4px"></td>
        <td>${cr?.date??""}</td><td>${cr?.particulars??""}</td><td>${cr?.folio??""}</td>
        <td style="text-align:right">${cr?fmtN(cr.amount):""}</td>
      </tr>`;
    }
    if (balanceDR > 0 || balanceCR > 0) {
      rows += `<tr style="background:#fef3c7;font-weight:600"><td></td><td>Balance c/d</td><td></td><td style="text-align:right">${fmtN(balanceDR)}</td><td style="background:#0f2744"></td><td></td><td>Balance c/d</td><td></td><td style="text-align:right">${fmtN(balanceCR)}</td></tr>`;
    }
    rows += `<tr style="background:#dbeafe;font-weight:700;border-top:2px double #000"><td></td><td>TOTAL</td><td></td><td style="text-align:right">${fmtN(grandTotal)}</td><td style="background:#0f2744"></td><td></td><td>TOTAL</td><td></td><td style="text-align:right">${fmtN(grandTotal)}</td></tr>`;

    const html = `<html><head><title>GL — ${data.accountName}</title>
      <style>body{font-family:Arial,Helvetica,sans-serif;color:#000;padding:10mm}
      table{width:100%;border-collapse:collapse;font-size:11px}
      th{background:#0f2744;color:#fff;padding:6px;text-align:center}
      td{padding:5px 8px;border-bottom:1px solid #e2e8f0}
      h2,h3,h4{text-align:center;margin:4px 0}</style></head><body>
      ${settings?`<h2>${settings.company_name}</h2>${settings.address?`<div style="text-align:center;font-size:10px">${settings.address}</div>`:""}${settings.tin_no?`<div style="text-align:center;font-size:10px">TIN: ${settings.tin_no}</div>`:""}`:""}
      <h3>GENERAL LEDGER</h3><h4>${data.accountName.toUpperCase()}</h4>
      <table><thead><tr><th>DATE</th><th>PARTICULARS</th><th>FOLIO</th><th>DEBIT</th><th style="background:#0f2744;width:4px"></th><th>DATE</th><th>PARTICULARS</th><th>FOLIO</th><th>CREDIT</th></tr></thead>
      <tbody>${rows}</tbody></table></body></html>`;
    const win = window.open("", "_blank");
    if (win) { win.document.write(html); win.document.close(); win.focus(); setTimeout(()=>win.print(), 400); }
  }

  return (
    <div className="t-account-card">
      <div className="t-account-title" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 16px" }}>
        <span style={{ flex: 1, textAlign: "center" }}>{data.accountName}</span>
        <div style={{ display: "flex", gap: 6 }} className="no-print">
          <button onClick={exportExcel} style={{ background:"#fff", color:"#000", border:"none", borderRadius:4, padding:"4px 10px", fontSize:"0.7rem", fontWeight:600, cursor:"pointer" }}>📊 Excel</button>
          <button onClick={printAccount} style={{ background:"#e2e8f0", color:"#000", border:"none", borderRadius:4, padding:"4px 10px", fontSize:"0.7rem", fontWeight:600, cursor:"pointer" }}>🖨️ Print</button>
        </div>
      </div>
      <table className="t-account-table">
        <thead>
          <tr>
            <th>DATE</th><th>PARTICULARS</th><th>FOLIO</th><th>DEBIT</th>
            <th className="t-divider"></th>
            <th>DATE</th><th>PARTICULARS</th><th>FOLIO</th><th>CREDIT</th>
          </tr>
        </thead>
        <tbody>
          {Array.from({ length: maxLen }).map((_, i) => {
            const dr = data.debitRows[i]; const cr = data.creditRows[i];
            return (
              <tr key={i}>
                <td>{dr?.date ?? ""}</td>
                <td>{dr?.particulars ?? ""}</td>
                <td>{dr?.folio ?? ""}</td>
                <td className="amount">{dr ? fmt(dr.amount) : ""}</td>
                <td className="t-divider"></td>
                <td>{cr?.date ?? ""}</td>
                <td>{cr?.particulars ?? ""}</td>
                <td>{cr?.folio ?? ""}</td>
                <td className="amount">{cr ? fmt(cr.amount) : ""}</td>
              </tr>
            );
          })}
          {(balanceDR > 0 || balanceCR > 0) && (
            <tr className="balance-row">
              <td></td><td>Balance c/d</td><td></td>
              <td className="amount">{balanceDR > 0 ? fmt(balanceDR) : ""}</td>
              <td className="t-divider"></td>
              <td></td><td>Balance c/d</td><td></td>
              <td className="amount">{balanceCR > 0 ? fmt(balanceCR) : ""}</td>
            </tr>
          )}
          <tr className="total-row">
            <td></td><td>TOTAL</td><td></td>
            <td className="amount">{fmt(grandTotal)}</td>
            <td className="t-divider"></td>
            <td></td><td>TOTAL</td><td></td>
            <td className="amount">{fmt(grandTotal)}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
